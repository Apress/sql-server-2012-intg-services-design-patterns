
USE SSISIncrementalLoad_Dest
GO

ALTER TABLE dbo.tblDest
 Add ColD int NULL
